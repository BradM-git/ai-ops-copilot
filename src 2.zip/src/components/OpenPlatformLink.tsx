// src/components/OpenPlatformLink.tsx
"use client";

export default function OpenPlatformLink({
  href,
  label,
}: {
  href: string;
  label: string;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noreferrer"
      onClick={(e) => e.stopPropagation()}
      className="
        inline-flex items-center justify-center
        rounded-md
        border border-[var(--ops-accent)]
        bg-black
        px-2.5 py-1.5
        text-xs font-semibold
        text-white
        transition-colors
        hover:bg-[var(--ops-surface)]
        focus:outline-none focus:ring-0
      "
      title="Open the source system to address this issue"
    >
      {label}
    </a>
  );
}
