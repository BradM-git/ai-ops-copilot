import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";
import { requireCron } from "@/lib/api";

function supabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient(url, serviceKey, { auth: { persistSession: false } });
}

export async function GET(req: Request) {
  try {
    requireCron(req);

    const supabase = supabaseAdmin();

    const { data: customers, error: custErr } = await supabase
      .from("customers")
      .select("id,name,is_active");

    if (custErr) return NextResponse.json({ error: custErr.message }, { status: 500 });

    const activeCustomers = (customers || []).filter((c) => c.is_active !== false);

    for (const c of activeCustomers) {
      const lookbackDays = 14;

      const { data: jira, error: jiraErr } = await supabase
        .from("jira_activity")
        .select("id,customer_id,created_at")
        .eq("customer_id", c.id)
        .order("created_at", { ascending: false })
        .limit(1);

      if (jiraErr) return NextResponse.json({ error: jiraErr.message }, { status: 500 });

      const last = jira?.[0]?.created_at ? new Date(jira[0].created_at) : null;
      const now = new Date();

      const daysSince = last ? Math.floor((now.getTime() - last.getTime()) / (1000 * 60 * 60 * 24)) : null;
      const isIssue = daysSince === null || daysSince >= lookbackDays;

      const title = "No recent client activity";
      const description = isIssue
        ? last
          ? `No Jira activity in the last ${lookbackDays} days. Last activity was ${daysSince} days ago.`
          : `No Jira activity found.`
        : `Recent activity detected. Last activity was ${daysSince} days ago.`;

      const actions = last
        ? [
            {
              label: "Open Jira",
              url: "https://jira.atlassian.com/",
            },
          ]
        : [];

      const payload = {
        customer_id: c.id,
        type: "no_client_activity",
        provider: "jira",
        title,
        description,
        status: isIssue ? "issue" : "ok",
        severity: isIssue ? "medium" : "info",
        count: isIssue ? 1 : 0,
        actions,
        last_run_at: new Date().toISOString(),
      };

      const { data: existing, error: existErr } = await supabase
        .from("alerts")
        .select("id")
        .eq("customer_id", c.id)
        .eq("type", "no_client_activity")
        .maybeSingle();

      if (existErr) return NextResponse.json({ error: existErr.message }, { status: 500 });

      if (existing?.id) {
        const { error: updErr } = await supabase.from("alerts").update(payload).eq("id", existing.id);
        if (updErr) return NextResponse.json({ error: updErr.message }, { status: 500 });
      } else {
        const { error: insErr } = await supabase.from("alerts").insert(payload);
        if (insErr) return NextResponse.json({ error: insErr.message }, { status: 500 });
      }
    }

    return NextResponse.json({ ok: true });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || "error" }, { status: 500 });
  }
}
