// src/components/AttentionItemCard.tsx

import React from "react";
import type { AlertRow } from "@/lib/attentionContract";
import { buildAttentionContractFromAlert } from "@/lib/attentionContract";

export default function AttentionItemCard({ alert }: { alert: AlertRow }) {
  const contract = buildAttentionContractFromAlert(alert);

  return (
    <div className="w-full text-left rounded-xl border border-slate-200 bg-white p-4">
      <div className="font-medium text-slate-900">{contract.headline}</div>
      <div className="text-sm text-slate-600 mt-1">{contract.why}</div>
      <div className="text-sm text-slate-600 mt-1">{contract.confidenceLabel}</div>
      <div className="text-sm text-slate-700 mt-2">{contract.action}</div>
    </div>
  );
}
