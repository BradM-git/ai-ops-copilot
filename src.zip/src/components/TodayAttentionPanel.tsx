// src/components/TodayAttentionPanel.tsx

import { supabase } from "@/lib/supabase";
import AttentionItemCard from "@/components/AttentionItemCard";
import type { AlertRow } from "@/lib/attentionContract";
import { isClosed, severityScoreFromAlert } from "@/lib/attentionContract";

export const dynamic = "force-dynamic";

async function getAttentionItems(): Promise<AlertRow[]> {
  const { data, error } = await supabase
    .from("alerts")
    .select(
      [
        "id",
        "customer_id",
        "type",
        "message",
        "amount_at_risk",
        "status",
        "created_at",

        "source_system",
        "primary_entity_type",
        "primary_entity_id",
        "confidence",
        "confidence_reason",
        "expected_amount_cents",
        "observed_amount_cents",
        "expected_at",
        "observed_at",
        "context",
      ].join(",")
    )
    .order("created_at", { ascending: false })
    .limit(200);

  if (error) {
    const msg =
      (error as any)?.message ||
      (error as any)?.details ||
      (error as any)?.hint ||
      (typeof error === "string" ? error : "Unknown Supabase error");
    throw new Error(`getAttentionItems failed: ${msg}`);
  }

  const rows = (data ?? []) as any[];

  return rows.map((r) => ({
    id: String(r.id),
    customer_id: r.customer_id ?? null,
    type: r.type ?? null,
    message: r.message ?? null,
    amount_at_risk: r.amount_at_risk ?? null,
    status: r.status ?? null,
    created_at: r.created_at ?? null,

    source_system: r.source_system ?? null,
    primary_entity_type: r.primary_entity_type ?? null,
    primary_entity_id: r.primary_entity_id ?? null,

    confidence: r.confidence ?? null,
    confidence_reason: r.confidence_reason ?? null,

    expected_amount_cents: r.expected_amount_cents ?? null,
    observed_amount_cents: r.observed_amount_cents ?? null,
    expected_at: r.expected_at ?? null,
    observed_at: r.observed_at ?? null,

    context: r.context ?? null,
  })) as AlertRow[];
}

export default async function TodayAttentionPanel() {
  let items: AlertRow[] = [];
  let loadError: string | null = null;

  try {
    items = await getAttentionItems();
  } catch (e: any) {
    loadError = e?.message ?? "Failed to load attention items";
  }

  if (loadError) {
    return (
      <section className="rounded-2xl border border-slate-200 bg-white p-4">
        <div className="text-sm font-semibold text-slate-900">Today’s Attention</div>
        <div className="mt-2 text-sm text-slate-700">{loadError}</div>
      </section>
    );
  }

  const ordered = items
    .filter((r) => !isClosed(r.status))
    .map((r) => ({ alert: r, score: severityScoreFromAlert(r) }))
    .sort((a, b) => b.score - a.score);

  return (
    <section className="rounded-2xl border border-slate-200 bg-white p-4">
      <div className="text-sm font-semibold text-slate-900">Today’s Attention</div>
      <div className="mt-1 text-sm text-slate-600">Only deviations that warrant intervention.</div>

      <div className="mt-4 space-y-3">
        {ordered.length === 0 ? (
          <div className="rounded-xl border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
            No attention items right now.
          </div>
        ) : (
          ordered.map(({ alert }) => <AttentionItemCard key={alert.id} alert={alert} />)
        )}
      </div>
    </section>
  );
}
