declare module "intuit-oauth";
