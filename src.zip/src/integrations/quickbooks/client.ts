// src/integrations/quickbooks/client.ts
import OAuthClient from "intuit-oauth";

export type QboEnv = "sandbox" | "production";

export type QboConnectionRow = {
  customer_id: string;
  realm_id: string;

  // NOTE: some call-sites may pass camelCase instead (accessToken/refreshToken)
  access_token?: string;
  refresh_token?: string;

  access_token_expires_at: string | null;
  refresh_token_expires_at: string | null;

  env?: QboEnv;

  updated_at?: string;
};

type QboAuthLike =
  | QboConnectionRow
  | {
      env?: QboEnv;
      realmId?: string;
      realm_id?: string;
      accessToken?: string;
      access_token?: string;
    };

function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing env var: ${name}`);
  return v;
}

function getQboApiBase(env: QboEnv) {
  return env === "sandbox"
    ? "https://sandbox-quickbooks.api.intuit.com"
    : "https://quickbooks.api.intuit.com";
}

// QBO app deep links are on qbo.intuit.com even for sandbox companies.
function getInvoiceDeepLink(realmId: string, invoiceId: string) {
  return `https://qbo.intuit.com/app/invoice?txnId=${encodeURIComponent(
    invoiceId
  )}&companyId=${encodeURIComponent(realmId)}`;
}

function oauthClient(env: QboEnv) {
  // Your project uses INTUIT_* vars (per your debug endpoint)
  const clientId = requireEnv("INTUIT_CLIENT_ID");
  const clientSecret = requireEnv("INTUIT_CLIENT_SECRET");
  const redirectUri = requireEnv("INTUIT_REDIRECT_URI");

  return new OAuthClient({
    clientId,
    clientSecret,
    environment: env,
    redirectUri,
  });
}

function pickRealmId(conn: QboAuthLike): string {
  const realmId =
    (conn as any).realm_id ??
    (conn as any).realmId ??
    (conn as any).companyId ??
    null;

  if (typeof realmId !== "string" || !realmId.trim()) {
    throw new Error("Missing realm id (realm_id/realmId) for QBO request");
  }
  return realmId.trim();
}

function normalizeAccessToken(conn: QboAuthLike): string {
  const raw =
    (conn as any).access_token ??
    (conn as any).accessToken ??
    null;

  if (typeof raw !== "string") {
    throw new Error(
      `Invalid access_token type (expected string, got ${typeof raw})`
    );
  }

  let token = raw.trim();

  // Strip accidental wrapping quotes
  if (
    (token.startsWith('"') && token.endsWith('"')) ||
    (token.startsWith("'") && token.endsWith("'"))
  ) {
    token = token.slice(1, -1).trim();
  }

  // Sanity check — QBO tokens are long opaque strings
  if (token.length < 20 || token.length > 5000) {
    throw new Error(`Malformed access_token length (${token.length})`);
  }

  return token;
}

export async function ensureFreshAccessToken(
  conn: QboConnectionRow,
  opts: {
    onTokenRefresh?: (update: {
      access_token: string;
      refresh_token: string;
      access_token_expires_at: string | null;
      refresh_token_expires_at: string | null;
    }) => Promise<void>;
    refreshSkewSeconds?: number;
  } = {}
): Promise<QboConnectionRow> {
  const env: QboEnv = conn.env ?? "sandbox";
  const skew = opts.refreshSkewSeconds ?? 120;

  // If expiry unknown, just return as-is (caller may still succeed)
  if (!conn.access_token_expires_at) return { ...conn, env };

  const expMs = Date.parse(conn.access_token_expires_at);
  if (Number.isNaN(expMs)) return { ...conn, env };

  const secondsLeft = Math.floor((expMs - Date.now()) / 1000);
  if (secondsLeft > skew) return { ...conn, env };

  const access_token = conn.access_token ?? "";
  const refresh_token = conn.refresh_token ?? "";

  if (!access_token || !refresh_token) {
    throw new Error("QBO refresh required but tokens are missing on connection row");
  }

  const oauth = oauthClient(env);

  oauth.setToken({
    access_token,
    refresh_token,
    token_type: "bearer",
    expires_in: 0,
    x_refresh_token_expires_in: 0,
  });

  const refreshed = await oauth.refresh();
  const j = refreshed.getJson();

  const new_access_token = String(j.access_token ?? "");
  const new_refresh_token = String(j.refresh_token ?? refresh_token);
  const expires_in = Number(j.expires_in ?? 0);

  const x_refresh_expires_in = j.x_refresh_token_expires_in
    ? Number(j.x_refresh_token_expires_in)
    : null;

  const access_token_expires_at =
    expires_in > 0 ? new Date(Date.now() + expires_in * 1000).toISOString() : null;

  const refresh_token_expires_at =
    x_refresh_expires_in && x_refresh_expires_in > 0
      ? new Date(Date.now() + x_refresh_expires_in * 1000).toISOString()
      : conn.refresh_token_expires_at ?? null;

  if (!new_access_token) throw new Error("QBO token refresh failed: missing access_token");

  if (opts.onTokenRefresh) {
    await opts.onTokenRefresh({
      access_token: new_access_token,
      refresh_token: new_refresh_token,
      access_token_expires_at,
      refresh_token_expires_at,
    });
  }

  return {
    ...conn,
    env,
    access_token: new_access_token,
    refresh_token: new_refresh_token,
    access_token_expires_at,
    refresh_token_expires_at,
  };
}

export type OverdueInvoice = {
  id: string;
  docNumber: string | null;
  customerName: string | null;
  totalAmt: number | null;
  balance: number | null;
  dueDate: string | null;
  txnDate: string | null;

  // direct link into QuickBooks
  deepLink: string;
};

export async function qboQuery<T = any>(conn: QboAuthLike, query: string): Promise<T> {
  const env: QboEnv = (conn as any).env ?? "sandbox";
  const base = getQboApiBase(env);

  const realmId = pickRealmId(conn);
  const token = normalizeAccessToken(conn);

  const url =
    `${base}/v3/company/${encodeURIComponent(realmId)}/query` +
    `?query=${encodeURIComponent(query)}` +
    `&minorversion=75`;

  const r = await fetch(url, {
    method: "GET",
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/json",
    },
    cache: "no-store",
  });

  if (!r.ok) {
    const txt = await r.text();
    throw new Error(`QBO query failed (${r.status}): ${txt}`);
  }

  return (await r.json()) as T;
}

export async function fetchOverdueInvoices(conn: QboAuthLike): Promise<OverdueInvoice[]> {
  const realmId = pickRealmId(conn);

  const query =
    "select Id, DocNumber, CustomerRef, TotalAmt, Balance, DueDate, TxnDate from Invoice " +
    "where Balance > '0' and DueDate < CURRENT_DATE maxresults 100";

  type QboInvoice = {
    Id?: string;
    DocNumber?: string;
    CustomerRef?: { name?: string };
    TotalAmt?: number;
    Balance?: number;
    DueDate?: string;
    TxnDate?: string;
  };

  type QboResp = { QueryResponse?: { Invoice?: QboInvoice[] } };

  const json = await qboQuery<QboResp>(conn, query);
  const invoices = json?.QueryResponse?.Invoice ?? [];

  return invoices.map((inv) => {
    const id = String(inv.Id ?? "");
    return {
      id,
      docNumber: inv.DocNumber ?? null,
      customerName: inv.CustomerRef?.name ?? null,
      totalAmt: typeof inv.TotalAmt === "number" ? inv.TotalAmt : null,
      balance: typeof inv.Balance === "number" ? inv.Balance : null,
      dueDate: inv.DueDate ?? null,
      txnDate: inv.TxnDate ?? null,
      deepLink: getInvoiceDeepLink(realmId, id),
    };
  });
}
