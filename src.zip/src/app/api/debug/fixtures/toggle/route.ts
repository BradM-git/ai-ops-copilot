// src/app/api/debug/fixtures/toggle/route.ts
import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

function supabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL!;
  const serviceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient(url, serviceKey, { auth: { persistSession: false } });
}

function ensureEnabled() {
  // Guardrail: only allow fixtures in dev unless explicitly enabled.
  const enabled = process.env.DEBUG_FIXTURES_ENABLED === "true";
  if (process.env.NODE_ENV !== "development" && !enabled) {
    return false;
  }
  return true;
}

export async function POST(req: Request) {
  if (!ensureEnabled()) {
    return NextResponse.json({ error: "Not found" }, { status: 404 });
  }

  const admin = supabaseAdmin();

  let body: any = null;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const integration = String(body?.integration || "");
  const enabled = Boolean(body?.enabled);

  if (!integration) {
    return NextResponse.json({ error: "Missing integration" }, { status: 400 });
  }

  // For now: one integration toggle = one representative alert type
  // This is intentionally opinionated for speed.
  const alertTypeByIntegration: Record<string, string> = {
    stripe: "missed_expected_payment",
  };

  const alertType = alertTypeByIntegration[integration];
  if (!alertType) {
    return NextResponse.json({ error: `Unknown integration: ${integration}` }, { status: 400 });
  }

  // Pick a real customer_id so the UI can still deep-link and show real context.
  // Prefer expected_revenue customer if available; else fall back to any customer.
  const { data: expPick } = await admin
    .from("expected_revenue")
    .select("customer_id")
    .limit(1)
    .maybeSingle();

  let customerId = expPick?.customer_id ?? null;

  if (!customerId) {
    const { data: custPick, error: custErr } = await admin
      .from("customers")
      .select("id")
      .limit(1)
      .maybeSingle();

    if (custErr) return NextResponse.json({ error: custErr.message }, { status: 500 });
    customerId = custPick?.id ?? null;
  }

  if (!customerId) {
    return NextResponse.json(
      { error: "No customers found. Create at least one customer (or expected_revenue row) before using fixtures." },
      { status: 400 }
    );
  }

  // Fixture identity: only touch rows we created (source_system='debug' + context.debug=true)
  const fixtureSelector = admin
    .from("alerts")
    .select("id, status")
    .eq("type", alertType)
    .eq("customer_id", customerId)
    .eq("source_system", "debug")
    .contains("context", { debug: true })
    .limit(1);

  const { data: existing } = await fixtureSelector.maybeSingle();

  if (enabled) {
    if (existing?.id) {
      // Ensure open
      const { error: uErr } = await admin
        .from("alerts")
        .update({ status: "open" })
        .eq("id", existing.id);

      if (uErr) return NextResponse.json({ error: uErr.message }, { status: 500 });
      return NextResponse.json({ ok: true, integration, enabled: true, action: "reopened", customer_id: customerId });
    }

    // Create fixture alert
    const now = new Date().toISOString();
    const expectedAt = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(); // 7 days ago
    const observedAt = new Date(Date.now() - 37 * 24 * 60 * 60 * 1000).toISOString(); // 37 days ago

    const payload: any = {
      customer_id: customerId,
      type: alertType,
      status: "open",
      message: "Fixture: expected payment missed (debug toggle)",
      amount_at_risk: 100000,

      source_system: "debug",
      primary_entity_type: "customer",
      primary_entity_id: customerId,

      confidence: "high",
      confidence_reason: "debug fixture",

      expected_amount_cents: 100000,
      observed_amount_cents: 0,
      expected_at: expectedAt,
      observed_at: observedAt,

      context: {
        debug: true,
        fixture: true,
        generated_at: now,
        note: "This row is created by /debug fixtures toggle for testing the attention surface.",
      },
    };

    const { error: cErr } = await admin.from("alerts").insert(payload);
    if (cErr) return NextResponse.json({ error: cErr.message }, { status: 500 });

    return NextResponse.json({ ok: true, integration, enabled: true, action: "created", customer_id: customerId });
  }

  // enabled == false: close fixture if exists
  if (existing?.id) {
    const { error: closeErr } = await admin.from("alerts").update({ status: "closed" }).eq("id", existing.id);
    if (closeErr) return NextResponse.json({ error: closeErr.message }, { status: 500 });

    return NextResponse.json({ ok: true, integration, enabled: false, action: "closed", customer_id: customerId });
  }

  return NextResponse.json({ ok: true, integration, enabled: false, action: "noop", customer_id: customerId });
}
